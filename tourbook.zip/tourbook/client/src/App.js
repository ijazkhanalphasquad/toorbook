import './App.css';
import { BrowserRouter, Route, Routes } from "react-router-dom"
import { ToastContainer } from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import { useDispatch } from 'react-redux';
import { useEffect } from 'react';
import { setUser } from './redux/feature/authSlice';
import Navbar from './components/Navbar';
import AddEditTour from './pages/AddEditTour';
import SingleTour from './pages/SingleTour';
import Dashboard from './pages/Dashboard';
import ProtectedRoute from './components/ProtectedRoute';
import TagTour from './pages/TagTours';

function App() {

  const dispatch = useDispatch()
  const userdata = JSON.parse(localStorage.getItem("profile"))

    useEffect(() => {
      dispatch(setUser(userdata))
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

  return (
    <BrowserRouter>
      <ToastContainer />
      <Navbar />
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/tours/search' element={<Home />} />
        <Route path='/tours/tag/:tag' element={<TagTour />} />
        <Route path='/login' element={<Login />} />
        <Route path='/register' element={<Register />} />
        <Route path='/addtour' element={<ProtectedRoute><AddEditTour /></ProtectedRoute>} />
        <Route path='/edittour/:id' element={<AddEditTour />} />
        <Route path='/tour/:id' element={<SingleTour />} />
        <Route path='/dashboard' element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
