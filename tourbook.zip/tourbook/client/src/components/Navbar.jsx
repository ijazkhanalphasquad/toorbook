import React, { useState } from 'react';
import {
  MDBNavbar,
  MDBContainer,
  MDBIcon,
  MDBNavbarNav,
  MDBNavbarItem,
  MDBNavbarToggler,
  MDBNavbarBrand,
  MDBCollapse,
} from 'mdb-react-ui-kit';
import { useDispatch, useSelector } from "react-redux"
import { userLogOut } from '../redux/feature/authSlice';
import { Link, useNavigate } from 'react-router-dom';
import { searchTours } from '../redux/feature/tourSlice';
import decode from 'jwt-decode';

export default function Navbar() {
  const [showNavColor, setShowNavColor] = useState(false);
  const [search, setSearch] = useState()
  const { user } = useSelector((state) => ({ ...state.auth }))
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const token = user?.token
  if (token) {
    const decodetoken = decode(token)
    if (decodetoken.exp * 1000 < new Date().getTime()) {
      dispatch(userLogOut())
    }
  }

  const handleLogout = () => {
    dispatch(userLogOut())
    navigate("/login")
  }
  const handleSearch = (e) => {
    e.preventDefault()
    if (search) {
      dispatch(searchTours(search))
      navigate(`/tours/search?searchQuery=${search}`)
      setSearch("")
    } else {
      navigate("/")
    }
  }
  return (
    <>
      <MDBNavbar expand='lg' dark bgColor='primary'>
        <MDBContainer  >
          <MDBNavbarBrand href='/'>TourBook</MDBNavbarBrand>
          <MDBNavbarToggler
            type='button'
            data-target='#navbarColor02'
            aria-controls='navbarColor02'
            aria-expanded='false'
            aria-label='Toggle navigation'
            onClick={() => setShowNavColor(!showNavColor)}
          >
            <MDBIcon icon='bars' fas />
          </MDBNavbarToggler>
          <MDBCollapse show={showNavColor} navbar>
            <MDBNavbarNav className='me-auto mb-2 mb-lg-0' style={{ justifyContent: "end" }}>
              <MDBNavbarItem className='active'>
                <Link className='nav-link text-light mx-1'  aria-current='page' to='/'>
                  HOME
                </Link>
              </MDBNavbarItem>
              {user?.result?._id && (<>
                <MDBNavbarItem>
                  <Link className='nav-link text-light mx-1' to='/addtour'>ADD TOUR</Link>
                </MDBNavbarItem>
                <MDBNavbarItem>
                  <Link className='nav-link text-light mx-1' to='/dashboard'>DASHBOARD</Link>
                </MDBNavbarItem>
              </>)}
              {user?.result?._id && (<>
                <MDBNavbarItem>
                  <Link className='nav-link text-light mx-1' to='#'>{`${user?.result?.firstname} ${user?.result?.lastname}`}</Link>
                </MDBNavbarItem>
              </>)}
              {user?.result?._id ? (<>
                <MDBNavbarItem>
                  <Link className='nav-link text-light mx-1' onClick={handleLogout}>LOGOUT</Link>
                </MDBNavbarItem>
              </>) : (<>
                <MDBNavbarItem>
                  <Link className='nav-link text-light mx-1' to='/login'>LOGIN</Link>
                </MDBNavbarItem>
              </>)}

              <form onSubmit={handleSearch} className="d-flex align-items-center p-0 m-0 mx-1 h-100 my-auto " style={{ backgroundColor: "transparent", borderRadius: "20px",border:"1px solid white" }}>
                <input value={search} onChange={(e) => setSearch(e.target.value)} className="m-0 p-0 px-1 border-0 outline-0" type="text" placeholder=" Search" aria-label="Search" style={{ borderRadius: "30px", border: "none", outline: "none",backgroundColor:"transparent",color:"white", }} />
                <MDBIcon icon="search" onClick={handleSearch} className="m-0 p-0 px-1" style={{ cursor: "pointer",color:"white" }} />
              </form>
            </MDBNavbarNav>
          </MDBCollapse>
        </MDBContainer>
      </MDBNavbar>
    </>
  );
}