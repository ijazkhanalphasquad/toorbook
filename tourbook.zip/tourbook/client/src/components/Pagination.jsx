import React from 'react';
import { MDBBtn, MDBPagination, MDBPaginationItem, MDBPaginationLink } from 'mdb-react-ui-kit';

export default function Pagination({ currentpage, setCurrentPage, dispatch, numberOfPages }) {
    const hide = currentpage == numberOfPages
    return (
        <nav aria-label='...'>
            <MDBPagination className={numberOfPages == 1 ? 'd-none' : 'mb-0'}>
                <MDBPaginationItem disabled>
                    <MDBBtn className='nav-link border-0 outline-none btn btn-light' type="button" data-mdb-ripple-color="dark" tabIndex={currentpage} aria-disabled='true' disabled={currentpage == 1} onClick={() => { dispatch(setCurrentPage(currentpage - 1)) }} >
                        Previous
                    </MDBBtn >
                    <MDBBtn className={currentpage == 1 ? 'd-none' : 'nav-link border-0 outline-none btn btn-light'} type="button" data-mdb-ripple-color="dark" onClick={() => { dispatch(setCurrentPage(currentpage = 1)) }} >
                        1
                    </MDBBtn >
                </MDBPaginationItem>
                <MDBPaginationItem active aria-current={currentpage}>
                    <MDBBtn className='nav-link border-0 outline-none btn btn-light' type="button" data-mdb-ripple-color="dark" onClick={() => { dispatch(setCurrentPage(currentpage)) }} >
                        {currentpage} <span className='visually-hidden'>(current)</span>
                    </MDBBtn >
                </MDBPaginationItem>
                <MDBPaginationItem>
                    <MDBBtn className={hide?'d-none':'nav-link border-0 outline-none btn btn-light'} type="button" data-mdb-ripple-color="dark" onClick={() => { dispatch(setCurrentPage(currentpage+1)) }} >{currentpage+1}</MDBBtn >
                </MDBPaginationItem>
                <MDBPaginationItem>
                    <MDBBtn className='nav-link border-0 outline-none btn btn-light' type="button" data-mdb-ripple-color="dark" tabIndex={currentpage==numberOfPages} aria-disabled='true' disabled={currentpage == numberOfPages} onClick={() => { dispatch(setCurrentPage(currentpage + 1)) }} >Next</MDBBtn >
                </MDBPaginationItem>
            </MDBPagination>
        </nav>
    );
}