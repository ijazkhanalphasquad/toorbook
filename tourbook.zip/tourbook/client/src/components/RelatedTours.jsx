import React from 'react'
import {
    MDBCard,
    MDBCardBody,
    MDBCardTitle,
    MDBCardText,
    MDBCardImage,
    MDBRipple
} from 'mdb-react-ui-kit';
import { Link } from 'react-router-dom';


const RelatedTours = ({ relatedTours, tourId }) => {

    const excerpt = (str) => {
        if (str.length > 45) {
            str = str.substring(0, 45) + "..."
        }
        return str
    }

    return (
        <>
            {relatedTours && relatedTours.length > 0 && (
                <>
                    {relatedTours.length > 1 && (
                        <>
                            <div className="d-flex align-items-center py-3">
                                <i style={{height:"2px",width:"100%",backgroundColor:"black"}}/>
                                <h4 className='text-center px-4 text-nowrap'>Related Tours</h4>
                                <i style={{ height: "2px", width: "100%", backgroundColor: "black" }} ></i>
                            </div>
                        </>
                    )}
                    <div className="d-flex flex-wrap">
                        {relatedTours.filter((items) => items._id !== tourId).splice(0, 3).map((item) => {
                            return (
                                <>
                                    <div className="col-md-4 col-12 p-3 ">
                                        <MDBCard className='d-block' style={{ boxShadow: " rgba(17, 12, 46, 0.15) 0px 48px 100px 0px" }} >
                                            <MDBRipple rippleColor='light' rippleTag='div' className='bg-image hover-overlay w-100'>
                                                <MDBCardImage src={item.imageFile} fluid alt='...' className='w-100' style={{ height: "180px" }} />
                                                <button className='border-0'>
                                                    <div className='mask' style={{ backgroundColor: 'rgba(251, 251, 251, 0.15)' }}></div>
                                                </button>
                                                <MDBCardTitle style={{ position: "absolute", top: "15px", left: "15px", color: "red" }}>{item.name}</MDBCardTitle>
                                            </MDBRipple>
                                            <MDBCardBody className='p-1'>
                                                <MDBCardText>{item?.tags.map((tag, index) => (<Link key={index} to={`/tours/tag/${tag}`} > #{tag}</Link>))}</MDBCardText>
                                                <MDBCardTitle>{item.title}</MDBCardTitle>
                                                <MDBCardText>
                                                    {excerpt(item.description)}
                                                    <Link to={`/tour/${item._id}`} >Read More</Link>
                                                </MDBCardText>
                                            </MDBCardBody>
                                        </MDBCard>
                                    </div>
                                </>
                            )
                        })}
                    </div>
                </>
            )}
        </>
    )
}

export default RelatedTours