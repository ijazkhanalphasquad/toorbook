import React from 'react'
import { MDBSpinner } from "mdb-react-ui-kit"

const Spinner = () => {
  return (
    <>
      <div className="vh-100 w-100 d-flex justify-content-center align-items-center">
        <MDBSpinner color='primary'>
          <span className='visually-hidden'>Loading...</span>
        </MDBSpinner>
      </div>

    </>
  )
}

export default Spinner