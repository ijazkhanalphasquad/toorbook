import React from 'react';
import {
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
  MDBCardImage,
  MDBRipple,
  MDBBtn,
  MDBIcon,
  MDBTooltip
} from 'mdb-react-ui-kit';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { likeTour } from '../redux/feature/tourSlice';


export default function TourCard({ imageFile, description, title, tags, _id, name, likes }) {
  const dispatch = useDispatch()
  const { user } = useSelector((state) => ({ ...state.auth }))
  const userId = user?.result?._id
  const excerpt = (str) => {
    if (str.length > 45) {
      str = str.substring(0, 45) + "..."
    }
    return str
  }
  const Like = () => {
    if (likes.length > 0) {
      return likes.find((like) => like === userId) ? (
        <>
          <MDBIcon fas icon='thumbs-up' />
          &nbsp;
          {likes.length > 2 ? (
            <><MDBTooltip tag={"a"} title={`you and ${likes.length - 1} other people likes`}>{likes.length} Likes</MDBTooltip></>
          ) : (
            `${likes.length} Like${likes.length > 1 ? "s" : ""}`
          )}

        </>
      ) : (
        <>
          <MDBIcon far icon='thumbs-up' />
          &nbsp;{likes.length} {likes.length === 1 ? 'Like' : 'Likes'}
        </>
      )

    }
    return (
      <>
        <MDBIcon far icon='thumbs-up' />
        &nbsp;like
      </>
    )
  }
  const handleLike = () => {
    dispatch(likeTour({ _id }))
  }
  return (
    <div className="col-md-4 col-lg-3 col-12 p-3 ">
      <MDBCard className='d-block' style={{ boxShadow: " rgba(17, 12, 46, 0.15) 0px 48px 100px 0px" }} >
        <MDBRipple rippleColor='light' rippleTag='div' className='bg-image hover-overlay w-100'>
          <MDBCardImage src={imageFile} fluid alt='...' className='w-100' style={{ height: "180px" }} />
          <button className='border-0'>
            <div className='mask' style={{ backgroundColor: 'rgba(251, 251, 251, 0.15)' }}></div>
          </button>
          <MDBCardTitle style={{ position: "absolute", top: "15px", left: "15px", color: "red" }}>{name}</MDBCardTitle>
        </MDBRipple>
        <MDBCardBody className='p-1'>
          <MDBBtn className='d-flex text-primary align-items-center'
            style={{ marginLeft: "auto", marginRight: "0px", backgroundColor: "transparent", border: "none", boxShadow: "none", outline: "none" }}
            onClick={!user?.result ? null : handleLike}
          >
            {user?.result ? (<>
              <Like />
            </>) : (<>
              <MDBTooltip tag={"a"} title={"please login for liking Tour"}>
                <Like />
              </MDBTooltip>
            </>)}
          </MDBBtn>
          <MDBCardText>{tags.map((tag, index) => (<Link key={index} to={`/tours/tag/${tag}`} > #{tag}</Link>))}</MDBCardText>
          <MDBCardTitle>{title}</MDBCardTitle>
          <MDBCardText>
            {excerpt(description)}
            <Link to={`/tour/${_id}`} >Read More</Link>
          </MDBCardText>
        </MDBCardBody>
      </MDBCard>
    </div>
  );
}