import React, { useEffect } from 'react'
import {
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
  MDBCardImage,
  MDBRipple,
  MDBIcon,
  MDBCol,
  MDBBtn
} from 'mdb-react-ui-kit';
import { Link } from 'react-router-dom';

import { useDispatch, useSelector } from 'react-redux';
import { deleteTour, getToursByUser } from '../redux/feature/tourSlice';
import Spinner from '../components/Spinner';
import { toast } from 'react-toastify';
const Dashboard = () => {

  const dispatch = useDispatch();
  const { user } = useSelector((state) => ({ ...state.auth }))
  const { userTours, loading } = useSelector((state) => ({ ...state.tour }))
  const userId = user?.result?._id
  // console.log(userTours);
  useEffect(() => {
    if (userId) {
      dispatch(getToursByUser(userId))
    }
        // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId])

  const excerpt = (str) => {
    if (str.length > 45) {
      str = str.substring(0, 40) + "..."
    }
    return str
  }
  if (loading) {
    return (<>
      <Spinner />
    </>)
  }
  const handleDelete = (id) => {
    if (window.confirm("are you sure want to delete the Tour")) {
      dispatch(deleteTour({ id, toast }))
    }
  }
  return (

    <div className='container p-4' style={{ boxShadow: " rgba(17, 12, 46, 0.15) 0px 48px 100px 0px" }}>
      {userTours.map((items) => {
        return (<>
          <MDBCard className='d-flex w-100 flex-md-row'  >
            <MDBRipple rippleColor='light' rippleTag='div' className='bg-image hover-overlay col-md-4'>
              <MDBCardImage src={items.imageFile}  alt='...' style={{ height: "200px" }} className="w-100 p-2" />
              <button className='border-0'>
                <div className='mask' style={{ backgroundColor: 'rgba(251, 251, 251, 0.15)' }}></div>
              </button>
            </MDBRipple>
            <MDBCardBody className='p-1 px-md-5 d-flex flex-row justify-content-md-center col-md-8'>
              <MDBCol className='col-8 d-flex flex-column justify-content-md-center'>
                <MDBCardTitle>{items?.title}</MDBCardTitle>
                <MDBCardText>
                  {excerpt(items.description)}
                  <Link to={`/tour/${items._id}`} >Read More</Link>
                </MDBCardText>
              </MDBCol>
              <MDBCol className='col-4 d-flex justify-content-md-center justify-content-end'>
                <MDBBtn className='d-flex align-items-center border-0' style={{ backgroundColor: "transparent", border: "none", boxShadow: "none" }} onClick={() => handleDelete(items._id)} >
                  <MDBIcon fas icon='trash' size='large' className='m-2 text-danger d-flex align-items-center' />
                </MDBBtn>
                <Link to={`/edittour/${items._id}`} className="d-flex align-items-center">
                  <MDBIcon fas icon='edit' size='large' className='m-2 text-primary d-flex align-items-center' />
                </Link>
              </MDBCol>
            </MDBCardBody>
          </MDBCard>
        </>)
      })}
    </div>
  )
}

export default Dashboard