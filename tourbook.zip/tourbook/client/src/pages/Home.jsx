import React, { useEffect } from 'react'
import TourCard from '../components/TourCard'
import { useDispatch, useSelector } from 'react-redux'
import { getTours, setCurrentPage } from '../redux/feature/tourSlice'
import Spinner from '../components/Spinner'
import Pagination from '../components/Pagination'

const Home = () => {
  const dispatch = useDispatch()
  const { tours, loading,currentPage,numberOfPages } = useSelector((state) => ({ ...state.tour }))
  useEffect(() => {
    dispatch(getTours(currentPage))
        // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage])

  if (loading) {
    return (
      <>
        <Spinner />
      </>
    )
  }

  return (
    <>
      {tours.length === 0 && (
        <h2>no data available</h2>
      )}
      <div className="container">
        <div className="d-flex flex-wrap" >
          {tours && tours.map((items, index) => {
            return (
              <TourCard key={index} {...items} />
            )
          })}
        </div>
        <div className="d-flex justify-content-center py-3">
          <Pagination setCurrentPage={setCurrentPage} currentpage={currentPage} numberOfPages={numberOfPages} dispatch={dispatch} />
        </div>
      </div>
    </>
  )
}

export default Home