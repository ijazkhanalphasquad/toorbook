import React, { useEffect, useState } from 'react'
import { MDBCard, MDBCardBody, MDBInput, MDBCardFooter, MDBValidation, MDBBtn, MDBIcon, MDBSpinner, } from "mdb-react-ui-kit"
import { Link, useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from "react-redux"
import { toast } from "react-toastify"
import { register } from '../redux/feature/authSlice'

const initialstate = {
    firstname: "",
    lastname: "",
    email: "",
    password: "",
    confirmpassword: ""
}

const Register = () => {
    const [formValue, setFormValue] = useState(initialstate)
    const { email, password, firstname, lastname, confirmpassword } = formValue;
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const { loading, error } = useSelector((state) => ({ ...state.auth }))

    useEffect(() => {
        error && toast.error(error)
    }, [error])

    const handleSubmit = (e) => {
        e.preventDefault()
        if (password !== confirmpassword) {
            return toast.error("password didn't match")
        }
        if (email && password && confirmpassword && firstname && lastname) {
            dispatch(register({ formValue, navigate, toast }))
        }
    }
    const onInputChange = (e) => {
        let { name, value } = e.target;
        setFormValue({ ...formValue, [name]: value })
    }

    return (
        <div
            style={{
                margin: "auto",
                padding: "15px",
                maxWidth: "450px",
                alignContent: "center",
                marginTop: "120px"
            }}
        >
            <MDBCard alignment='center'>
                <MDBIcon fas icon='user-circle' className='fa-2x'></MDBIcon>
                <h5>Sign Up</h5>
                <MDBCardBody>
                    <MDBValidation onSubmit={handleSubmit} noValidate autoComplete='off' className='row g-3'>
                        <div className="col-md-6">
                            <MDBInput label="First Name" type="text" value={firstname} name="firstname" onChange={onInputChange} required validation="please provide your email" autoComplete='off' />
                        </div>
                        <div className="col-md-6">
                            <MDBInput label="Last Name" type="text" value={lastname} name="lastname" onChange={onInputChange} required validation="please provide your email" autoComplete='off' />
                        </div>
                        <div className="col-md-12">
                            <MDBInput label="Email" type="email" value={email} name="email" onChange={onInputChange} required validation="please provide your email" autoComplete='off' />
                        </div>
                        <div className="col-md-12">
                            <MDBInput label="Password" type="password" value={password} name="password" onChange={onInputChange} required validation="please provide your password" autoComplete="off" />
                        </div>
                        <div className="col-md-12">
                            <MDBInput label="Confirm Password" type="password" value={confirmpassword} name="confirmpassword" onChange={onInputChange} required validation="please provide your password" autoComplete="off" />
                        </div>
                        <div className="col-12">
                            <MDBBtn style={{ width: "100%" }} className="mt-2">
                                {loading && (
                                    <MDBSpinner
                                        size='sm'
                                        className='me-2'
                                        tag="span"
                                        role="status"
                                    />
                                )}
                                Register
                            </MDBBtn>
                        </div>
                    </MDBValidation>
                </MDBCardBody>
                <MDBCardFooter>
                    <Link to={"/login"}>
                        <p>already have an account ? sign in</p>
                    </Link>
                </MDBCardFooter>

            </MDBCard>
        </div>
    )
}

export default Register