import React, { useEffect } from 'react'
import {
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
  MDBCardImage,
  MDBRipple,
  MDBContainer,
  MDBIcon
} from 'mdb-react-ui-kit';

import { useDispatch, useSelector } from 'react-redux';
import { useParams } from "react-router-dom"
import { getRelatedTours, getTour } from '../redux/feature/tourSlice';
import moment from 'moment';
import RelatedTours from '../components/RelatedTours';


const SingleTour = () => {
  const { id } = useParams()
  const dispatch = useDispatch();
  const { tour,relatedTours } = useSelector((state) => ({ ...state.tour }))
  const tags = tour?.tags

  useEffect(() => {
    tags && dispatch(getRelatedTours(tags))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tags])
  
  useEffect(() => {
    if (id) {
      dispatch(getTour(id))
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id])

  return (
    <MDBContainer >
      <MDBCard className='p-2' style={{ boxShadow: " rgba(17, 12, 46, 0.15) 0px 48px 100px 0px" }} >
        <MDBRipple rippleColor='light' rippleTag='div' className='bg-image hover-overlay w-100'>
          <MDBCardImage src={tour.imageFile} fluid alt='...' className='w-100'
          // style={{height:"400px"}}
          />
          <button className='border-0'>
            <div className='mask' style={{ backgroundColor: 'rgba(251, 251, 251, 0.15)' }}></div>
          </button>
        </MDBRipple>
        <MDBCardBody className='p-1'>
          <MDBCardTitle className='text-center'>{tour.title}</MDBCardTitle>
          <MDBCardTitle className='d-flex align-items-center'>Created By : {tour.name}</MDBCardTitle>
          <MDBCardText style={{ color: "darkgray" }}>{tour.tags && tour.tags.map((items, index) => (<span key={index}> #{items}</span>))}</MDBCardText>
          <MDBCardText style={{ color: "darkgray" }} className="py-1">
            <MDBIcon far icon='calendar-alt' size='large' className='m-2' />
            {moment(tour.createdAt).fromNow()}
          </MDBCardText>
          <MDBCardText>
            {tour.description}
          </MDBCardText>
        </MDBCardBody>
      </MDBCard>

      <RelatedTours relatedTours={relatedTours} tourId={id} />

    </MDBContainer>
  )
}

export default SingleTour