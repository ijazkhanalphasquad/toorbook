import React, { useEffect } from 'react';
import {
    MDBCard,
    MDBCardBody,
    MDBCardTitle,
    MDBCardText,
    MDBCardImage,
    MDBRipple
} from 'mdb-react-ui-kit';
import { Link, useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import Spinner from '../components/Spinner';
import { getToursByTag } from '../redux/feature/tourSlice'

export default function TagTour() {
    const { tag } = useParams()
    const dispatch = useDispatch()
    const { tagTours, loading } = useSelector((state) => ({ ...state.tour }))
    useEffect(() => {
        if (tag) {
            dispatch(getToursByTag(tag))
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [tag])

    if (loading) {
        return (
            <>
                <Spinner />
            </>
        )
    }

    const excerpt = (str) => {
        if (str.length > 45) {
            str = str.substring(0, 45) + "..."
        }
        return str
    }

    return (
        <>
            <div className="container">
                <div className="d-flex flex-wrap" >
                    {tagTours && tagTours.map((items, index) => {
                        return (
                            <div className="col-md-4 col-lg-3 col-12 p-3 " key={index}>
                                <MDBCard className='d-block' style={{ boxShadow: " rgba(17, 12, 46, 0.15) 0px 48px 100px 0px" }} >
                                    <MDBRipple rippleColor='light' rippleTag='div' className='bg-image hover-overlay w-100'>
                                        <MDBCardImage src={items.imageFile} fluid alt='...' className='w-100' style={{ height: "180px" }} />
                                        <button className='border-0'>
                                            <div className='mask' style={{ backgroundColor: 'rgba(251, 251, 251, 0.15)' }}></div>
                                        </button>
                                        <MDBCardTitle style={{ position: "absolute", top: "15px", left: "15px", color: "red" }}>{items.name}</MDBCardTitle>
                                    </MDBRipple>
                                    <MDBCardBody className='p-1'>
                                        <MDBCardText>{items.tags.map((tag, index) => (<Link key={index} to={`/tours/tag/${tag}`} > #{tag}</Link>))}</MDBCardText>
                                        <MDBCardTitle>{items.title}</MDBCardTitle>
                                        <MDBCardText>
                                            {excerpt(items.description)}
                                            <Link to={`/tour/${items._id}`} >Read More</Link>
                                        </MDBCardText>
                                    </MDBCardBody>
                                </MDBCard>

                            </div>
                        )
                    })}
                </div>
            </div>
        </>
    );
}