import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken"

import userModel from "../models/user.js";
const secret = "test"

export const signin = async (req, res) => {
    const {email, password } = req.body;
    try {
        const olduser = await userModel.findOne({ email })
        if (!olduser) {
            return res.status(400).json({ message: "user donst exist" })
        }
        const passwordcorrect = await bcrypt.compare(password,olduser.password)
        if(!passwordcorrect){
            return res.status(404).json({message:"invalid credintial"})
        }
        const token = jwt.sign({ email: olduser.email, id: olduser._id }, secret, { expiresIn: "1h" })

        res.status(201).json({ result:olduser, token })

    } catch (error) {
        res.status(404).json({ message: "somthing went wrong" })
        console.log(error);
    }
}

export const signup = async (req, res) => {
    const { firstname, lastname, email, password } = req.body;
    try {
        const olduser = await userModel.findOne({ email })
        if (olduser) {
            return res.status(400).json({ message: "user already exist" })
        }

        const hashpassword = await bcrypt.hash(password, 12)
        const result = await userModel.create({
            email,
            password:hashpassword,
            firstname,
            lastname,
        })
        const token = jwt.sign({ email: result.email, id: result._id }, secret, { expiresIn: "1h" })
        res.status(201).json({ result, token })

    } catch (error) {
        res.status(404).json({ message: "somthing went wrong" })
        console.log(error);
    }
}

// export const googlelogIn = async (req,res)=>{
//     const {email , googleId , name , token} = req.body

//     try {
//         const olduser = await userModel.findOne({email})
//         if(olduser){
//             const result = {_id : olduser._id.toString(), email,name}
//            return res.status(200).json(result,token)
//         }
//         const result = await userModel.create({
//             email,
//             name,
//             googleId
//         })
//         res.status(200).json(result, token)

//     } catch (error) {
//         res.status(404).json({ message: "somthing went wrong" })
//         console.log(error);
//     }
// }