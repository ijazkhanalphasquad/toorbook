import express from "express";
import cors from "cors";
import morgan from "morgan";
import mongoose from "mongoose";
import userRouter from "./routes/user.js"
import tourRouter from "./routes/tour.js"

const port = 5000;

const app = express()

app.use(morgan("dev"))
app.use(express.json({limit:"30mb",extended:true}))
app.use(express.urlencoded({limit:"30mb",extended:true}))
app.use(cors());

app.use("/users",userRouter)
app.use("/tour",tourRouter)

const MONGO_DB = "mongodb+srv://ijazkhanalphasquad:ijazkhanafridi@cluster0.0vq7mkm.mongodb.net/tourbook?retryWrites=true&w=majority"


mongoose.set('strictQuery', false);

app.get("/",(req,res)=>{
    res.send("hello world")
})

mongoose.connect(MONGO_DB).then(()=>{
    app.listen(port,()=>{
        console.log(`app is running on port ${port}`);
    })
}).catch((error)=>{
    console.log(error);
})