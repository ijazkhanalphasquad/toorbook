import  express  from "express";
const router = express.Router()
import auth from "../middlewares/auth.js";
import { createTour, deleteTour, getRelatedTour, getTour, getTours, getToursBySearch, getToursByTag, getToursByUser, likeTour, updateTour } from "../controllers/tour.js";


router.post("/",auth,createTour )
router.get("/",getTours )
router.get("/search",getToursBySearch )
router.post("/relatedTours",getRelatedTour)
router.get("/tag/:tag",getToursByTag )
router.get("/:id",getTour )
router.get("/userTours/:id",auth,getToursByUser )
router.delete("/:id",auth,deleteTour )
router.patch("/:id",auth,updateTour )
router.patch("/like/:id",auth,likeTour )

export default router